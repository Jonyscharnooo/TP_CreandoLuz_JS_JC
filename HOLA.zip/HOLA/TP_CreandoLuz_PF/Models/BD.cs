using System.Data.SqlClient;
using Dapper;
using System.Collections.Generic;
namespace TP_CreandoLuz_PF.Models{
    public class BD{
        private static string _connectionString = @"Server=A-PHZ2-CIDI-055;DataBase=BDD_CreandoLuzForm;Trusted_Connection=True";
        public static void MandarForm(Form Frm){
        string sql = "INSERT INTO Form (Nombre, Apellido, Telefono, Mail, Cuerpo) VALUES (@pNombre, @pApellido, @pTelefono, @pMail, @pCuerpo)";
        using(SqlConnection db = new SqlConnection(_connectionString)){
            db.Execute(sql, new {pNombre = Frm.Nombre, pApellido = Frm.Apellido, pTelefono = Frm.Telefono, pMail = Frm.Mail, pCuerpo = Frm.Cuerpo});
        }
    }
    }
}