namespace TP_CreandoLuz_PF.Models
{
    public class Form
    {
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public string? Telefono { get; set; }
        public string? Mail { get; set; }
        public string? Cuerpo { get; set; }
    }
}